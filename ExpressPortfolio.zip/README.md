# ExpressJS Portfolio

This is My Personal Portfolio project made in ExpreessJS,NodeJS and beautified with handlebars engine.

## Installation

1. Clone This repo
2. Run Following in bash

```bash
npm install
```
3. Run App Server By entering the following command in bash:
```bash
npm start
```
4. Navigate to [localhost:3000](localhost:3000) to see results.
